﻿using System;
using System.Collections.Generic;
using System.Linq;
using FabricTrade.Database;
using FabricTrade.WindowGroup;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace FabricTrade.WindowGroup
{
    /// <summary>
    /// Логика взаимодействия для ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        Entities entities;
        User user;
        public ProductWindow(Entities entities, User user)
        {
            InitializeComponent();
            this.entities = entities;
            this.user = user;

            //заполнение элементов для сортировки
            string[] sortMas = new[] { "По убыванию цены", 
                "По возрастанию цены", 
                "Без сортировки" };
            SortInput.ItemsSource = sortMas;

            //заполнение элементов для фильтрации
            string[] filtrMas = new[] { "Все производители",
                "БТК Текстиль",
                "Империя ткани",
                "Комильфо",
                "Май Фабрик" };
            FiltrInput.ItemsSource = filtrMas;

            //приветственная надпись пользователя
            if (user != null )
            {
                HelloUser.Text = $"{user.UserSurname} " +
                    $"{user.UserName} {user.UserPatronymic}";
                return;
            }

            ProductOutput.ItemsSource = entities.Product.ToList();
            //вывод количества записей
            CountOutput.Text = $"{entities.Product.Count()}" +
                $" из {entities.Product.Count()}";
        }

        private void AuthorizationButton_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        private void SearchInput_TextChanged(object sender, TextChangedEventArgs e)
        {
            SearchMethod(SearchInput.Text, SortInput.Text, FiltrInput.Text);
        }

        private void SortInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SearchMethod(SearchInput.Text, e.AddedItems[0] as string,
                FiltrInput.Text);
        }

        private void FiltrInput_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            SearchMethod(SearchInput.Text, SortInput.Text,
                e.AddedItems[0] as string);         
        }

        //метод для сортировки, поиска и фильтрации записей
        private void SearchMethod(string searchValue, string sortValue, string filtrValue)
        {
            var productList = entities.Product.ToList();

            //поиск записей по всем доступным данным
            if (searchValue != null )
            {
                productList = productList.Where(x =>
                x.ProductName.ToLower().Contains(SearchInput.Text) ||
                x.ProductDescription.ToLower().Contains(SearchInput.Text) ||
                x.Manufacturer.ManufacturerName.ToLower().Contains(SearchInput.Text) ||
                x.ProductCost.ToString().ToLower().Contains(SearchInput.Text)).ToList();
            }            

            //фильтрация записей
            if (filtrValue == "Все производители")
            {
                productList = productList.ToList();
            }
            if (filtrValue == "БТК Текстиль")
            {
                productList = productList.Where
                    (x => x.ProductManufacturer == 1).ToList();
            }
            if (filtrValue == "Империя ткани")
            {
                productList = productList.Where
                    (x => x.ProductManufacturer == 2).ToList();
            }
            if (filtrValue == "Комильфо")
            {
                productList = productList.Where
                    (x => x.ProductManufacturer == 3).ToList();
            }
            if (filtrValue == "Май Фабрик")
            {
                productList = productList.Where
                    (x => x.ProductManufacturer == 4).ToList();
            }

            //сортировка записей
            if (sortValue == "По убыванию цены")
            {
                productList = productList.OrderByDescending
                    (x => x.ProductCost).ToList();
            }
            if (sortValue == "По возрастанию цены")
            {
                productList = productList.OrderBy
                    (x => x.ProductCost).ToList();
            }
            if (sortValue == "Без сортировки")
            {
                productList = productList.ToList();
            }

            ProductOutput.ItemsSource = productList;
            CountOutput.Text = $"{productList.Count()}" +
                $" из {entities.Product.Count()}";
        }
    }
}
